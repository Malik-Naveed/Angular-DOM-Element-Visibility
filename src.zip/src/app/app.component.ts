import { Component, OnInit, ViewChild, ElementRef, HostListener } from '@angular/core';
import { VisibilityService } from './visibility.service';

import {Observable, observable, fromEvent} from 'rxjs';
import {take, filter, distinctUntilChanged, map, distinctUntilKeyChanged, tap} from 'rxjs/operators';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent implements OnInit  {

  name = "You";

  constructor() {}
  ngOnInit()
  {
    fromEvent(window, 'scroll')
    .pipe(
      // filter(event => 
      //   {
      //     console.log(event)
      //     return event || event['target'] || event['target']['body'] 
      //   }
      // ),
      map(event => 
        { 
          // console.log('map')
          // console.log(event.target['body']['scrollHeight'])
          return {body:event.target['body'], scrollHeight: event.target['body']['scrollHeight']}
        }
      ),
      // tap(data => {
      //   console.log(`tap ${data}`)
      // }),

      distinctUntilChanged((prev, curr) => {
        //console.log(`prev ${prev}\t curr ${curr}`)
        // console.log(prev)
        // console.log(curr)
        // console.log('*******************')
        return prev['scrollHeight'] == curr['scrollHeight']
      }),
      
      //distinctUntilKeyChanged('scrollHeight')
      // distinctUntilChanged((prev, curr) => 
      // { 
      //   console.log(`prev: ${prev['scrollHeight']} \t curree ${curr['scrollHeight']}`)
      //   return prev['scrollHeight'] === curr['scrollHeight']
      // }
      // )
    )
    // .subscribe((event:Event) => {
    //   console.log(`offset height: ${event.target['body']['offsetHeight']}\nClient Height: ${event.target['body']['clientHeight']}
    //   Scroll height: ${event.target['body']['scrollHeight']}\nScroll Top: ${event.target['body']['scrollTop']}
    //   `)
    // })
    .subscribe((event:any) => {
      console.log('subs')
      //console.log(event)
      console.log(`offset height: ${event.body['offsetHeight']}\nClient Height: ${event.body['clientHeight']}
      Scroll height: ${event.body['scrollHeight']}\nScroll Top: ${event.body['scrollTop']}
      `)
    })
  }

  // @HostListener("window:scroll", ["$event"]) onWindowScroll(event: Event) {
  //   //console.log('onWindowScroll event')
  //   //console.log(event)
    
  //     console.log(`offset height: ${event.target['body']['offsetHeight']}\nClient Height: ${event.target['body']['clientHeight']}
  //     Scroll height: ${event.target['body']['scrollHeight']}\nScroll Top: ${event.target['body']['scrollTop']}
  //     `)
  // }

}
