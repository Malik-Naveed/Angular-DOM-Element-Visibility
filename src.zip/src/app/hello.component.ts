import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'hello',
  template: `<h1 style="height: 150px!important;">Hello, {{name}}!</h1>`
})
export class HelloComponent implements OnInit {

  @Input()
  name: string;

  ngOnInit() {
    //console.log("Initalizing lazy component.")
  }
}
