import { Directive, TemplateRef, ViewContainerRef, Input, ElementRef} from '@angular/core';
import { VisibilityService } from './visibility.service';
import {take, filter } from 'rxjs/operators';

@Directive({ selector: '[visibleWith]'})
export class VisibleWith {

  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private visibilityService: VisibilityService) { }

  @Input()
  set visibleWith(element) {
    this.visibilityService
        .elementInSight(new ElementRef(element))
        .pipe(
          // filter(visible => {
          //   console.log(`visible: ${visible}`)
          //   return visible
          // }),
           //take(4)
           )
        .subscribe((data) => {
          //console.log(`data : ${data}`)
          if (data)
            this.viewContainer.createEmbeddedView(this.templateRef);   
          else
            this.viewContainer.remove(0)
        }); 
  }

}