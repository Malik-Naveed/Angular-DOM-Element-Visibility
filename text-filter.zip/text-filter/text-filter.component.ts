import { Component, EventEmitter, Input, OnInit, Output, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'text-filter',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './text-filter.component.html',
  styleUrls: ['./text-filter.component.css']
})
export class TextFilterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  @Input() fieldName: string = ''
  @Input() tooltips: {info?:{placement?: "auto"|"left"|"right"|"top"|"bottom", hide?: boolean, hideIcon?: boolean, hideOnEditorClick?: boolean, hideInfoOnEditorClickInSeconds?: number}, 
    help?: {placement?: "auto"|"left"|"right"|"top"|"bottom", hide?: boolean, hideIcon?: boolean}} =
    {info: {placement: 'auto', hide: false, hideOnEditorClick: false, hideIcon: false, hideInfoOnEditorClickInSeconds: 20}, help: {placement: 'auto', hide: false, hideIcon: false}}
  @Output() getFilters: EventEmitter<{logic?: 'and'|'or', operator?: string, value?: string}[]> = new EventEmitter()
  //@Output() getSplitFilters: EventEmitter<{logic?: 'and'|'or', operator?: string, value?: string}[]> = new EventEmitter()
  logicKeywords = ['and', 'or'];
  operatorKeywords = ['notcontains', 'contains', 'eq', 'neq', 'startswith', 'notstartswith', 'endswith', 'notendswith', 'inlist', 'notinlist', 'containsinlist', 'notcontainsinlist'
                    , 'startswithinlist', 'notstartswithinlist', 'endswithinlist', 'notendswithinlist'];

  filters :{logic?: 'and'|'or', operator?: string, value?: string, fieldName?: string}[]
  splitFilters :{logic?: 'and'|'or', operator?: string, value?: string}[]

  isOpen: {info: boolean, help: boolean} = {info: false, help: false}
  isEdiorClickOpen: boolean = false
  hideInfoOnEditorClickInSeconds_Default: number = 20

  private splitTheFilters()
  {
    this.splitFilters = []
    if (this.filters)
    {
      this.filters.forEach((f: {logic?: 'and'|'or', operator?: string, value?: string}, index, array) => {
        if (f?.operator == 'inlist' || f?.operator == 'notinlist' || f?.operator?.indexOf('inlist') < 0)
        {
          this.splitFilters.push(f)
        }
        else if (f?.operator?.indexOf('inlist') > -1)
        {
          f?.value?.split(',').forEach((v, i, arr) =>{
            this.splitFilters.push({
              logic: i == 0 ? f?.logic : f?.operator.indexOf('not') > -1 ? 'and' : 'or',
              value: v?.trim(),
              operator : f?.operator?.replace('inlist', '')
              })
            })
        }
      })
    }
    //this.getSplitFilters.emit(this.splitFilters)
  }

  onHiddenInfo()
  {
    this.isOpen.info = false
  }
  onHiddenHelp()
  {
    this.isOpen.help = false
  }
  onHelpIconClick()
  {
    this.isOpen.info = false
    this.isOpen.help = !this.isOpen.help 
  }
  onInfoIconClick(isInfoIcon: boolean)
  {
    this.isEdiorClickOpen = !isInfoIcon 
    if (this.isEdiorClickOpen && !this.tooltips?.info?.hideOnEditorClick)
    {
      setInterval(() => {
        if (this.isEdiorClickOpen && this.isOpen.info) 
        {
          this.isOpen.info = false
          this.tooltips.info.hideOnEditorClick = true
        }
      }, ((this.tooltips.info.hideInfoOnEditorClickInSeconds ? this.tooltips.info.hideInfoOnEditorClickInSeconds : this.hideInfoOnEditorClickInSeconds_Default) * 1000));
    }
    if (isInfoIcon || (!isInfoIcon && !this.tooltips?.info?.hideOnEditorClick))
    {
      this.isOpen.help = false
      this.isOpen.info = !this.isOpen.info 
    }
  }
  onKeyup(e: KeyboardEvent) {
    if (e.key.indexOf('Arrow') > -1) return
    if (e.key.indexOf('Enter') > -1) this.setCaretToEnd(e.target)
    
    this.setCaretToCurrentPosition(e)
    // if (e.keyCode != 35 && e.keyCode != 36)// && e.keyCode != 32)
    //   this.setCursor()
    
  }

  parse(e: KeyboardEvent)
  {
    e.preventDefault();
    //if (e.keyCode == 32) 
    {
      //console.log(e);      
      let textContent: string =  (e.target as HTMLInputElement).textContent;
      let newInnerHtml: string = this.formatted(textContent, 32);
      (e.target as HTMLInputElement).innerHTML = newInnerHtml 
      //this.splitTheFilters()
    }
    //if (e.keyCode == 32) 
    //this.setCaretToEnd(event.target);
  }

  // [textContent]="textFormatted"
  // (input)="textValue = $event.target.textContent"

  setCaretToEnd(target/*: HTMLDivElement*/) {
    const range = document.createRange();
    const sel = window.getSelection();
    range.selectNodeContents(target);
    range.collapse(false);
    sel.removeAllRanges();
    sel.addRange(range);
    target.focus();
    range.detach(); // optimization
  
    // set scroll to the end if multiline
    target.scrollTop = target.scrollHeight; 
  }

  setCaretToCurrentPosition(e: KeyboardEvent)
  {
    //get current cursor position
    const sel = window.getSelection();
    const node = sel.focusNode;
    const offset = sel.focusOffset;
    const pos = this.getCursorPosition(e.target, node, offset, { pos: 0, done: false });
      
    if (offset === 0) pos.pos += 0.5;

    //editor.innerHTML = 
    let editor: HTMLInputElement = e.target as HTMLInputElement
    this.parse(e);

    // restore the position
    sel.removeAllRanges();
    const range = this.setCursorPosition(editor, document.createRange(), {
      pos: pos.pos,
      done: false,
    });
    range.collapse(true);
    sel.addRange(range);
  }

  getCursorPosition(parent, node, offset, stat) {
    if (stat.done) return stat;
  
    let currentNode = null;
    if (parent.childNodes.length == 0) {
      stat.pos += parent.textContent.length;
    } else {
      for (let i = 0; i < parent.childNodes.length && !stat.done; i++) {
        currentNode = parent.childNodes[i];
        if (currentNode === node) {
          stat.pos += offset;
          stat.done = true;
          return stat;
        } else this.getCursorPosition(currentNode, node, offset, stat);
      }
    }
    return stat;
  }
  
  //find the child node and relative position and set it on range
  setCursorPosition(parent, range, stat) {
    let currentNode = null
    if (stat.done) return range;
  
    if (parent.childNodes.length == 0) {
      if (parent.textContent.length >= stat.pos) {
        range.setStart(parent, stat.pos);
        stat.done = true;
      } else {
        stat.pos = stat.pos - parent.textContent.length;
      }
    } else {
      for (let i = 0; i < parent.childNodes.length && !stat.done; i++) {
        currentNode = parent.childNodes[i];
        this.setCursorPosition(currentNode, range, stat);
      }
    }
    return range;
  }  
  
  oepratorToFriendlyString(operator: string): string
  {
    let friendlyString: string = null
    switch(operator)
    {
      case 'notcontainsinlist':
        friendlyString = 'not contains in list'
        break
      case 'containsinlist':
        friendlyString = 'contains in list'
        break
      case 'notcontains':
        friendlyString = 'not contains'
        break
      case 'notinlist':
        friendlyString = 'not in list'
        break
      case 'inlist':
        friendlyString = 'in list'
        break
      case 'startswith':
        friendlyString = 'starts with'
        break
      case 'notstartswith':
        friendlyString = 'not starts with'
        break
      case 'notendswith':
        friendlyString = 'not ends with'
        break
      case 'endswith':
        friendlyString = 'ends with'
        break
      case 'startswithinlist':
        friendlyString = 'starts with in list'
        break
      case 'notstartswithinlist':
        friendlyString = 'not starts with in list'
        break
      case 'notendswithinlist':
        friendlyString = 'not ends with in list'
        break
      case 'endswithinlist':
        friendlyString = 'ends with in list'
        break
      case 'eq':
        friendlyString = 'equals'
        break
      case 'neq':
        friendlyString = 'not equals'
        break
      default:
        friendlyString = null
    }

    return friendlyString
  }

  formatted(message: any, keyCode: number = 0) {
    let newHTML: string = '';
    //console.log(message);
    message = message.replace(/[\s]+/g, ' ');
    //if (message.toLowerCase().indexOf('not contains') > -1) 
    {
      message = message.replaceAll('not contains in list', 'notcontainsinlist');
      message = message.replaceAll('contains in list', 'containsinlist');      
      message = message.replaceAll('not starts with in list', 'notstartswithinlist');
      message = message.replaceAll('starts with in list', 'startswithinlist');
      message = message.replaceAll('not ends with in list', 'notendswithinlist');
      message = message.replaceAll('ends with in list', 'endswithinlist');      

      message = message.replaceAll('not contains', 'notcontains');
      message = message.replaceAll('not in list', 'notinlist');
      message = message.replaceAll('in list', 'inlist');
      message = message.replaceAll('not starts with', 'notstartswith');
      message = message.replaceAll('starts with', 'startswith');      
      message = message.replaceAll('not ends with', 'notendswith');
      message = message.replaceAll('ends with', 'endswith');
            
      message = message.replaceAll('not equals', 'neq');
      message = message.replaceAll('equals', 'eq');
      
      //console.log(message);
    }
    let previousCssClass = 'logic'
    this.filters = [{logic: 'and'}]
    let indexer: number = 0
    let optFriendString: string = null
    message
      //.trim()
      .split(' ')
      .forEach((val, index, array) => {
        optFriendString = null
        // If word is statement
        // console.log(this.logicKeywords)
        // console.log(val.trim())
        //&nbsp;
        //+ (keyCode == 32 ? '' :'')
        if (this.logicKeywords.indexOf(val.trim()) > -1 && (previousCssClass == 'value' || index == 0))
        {
          newHTML += "<span class ='logic'>" + val  + "</span>";
          previousCssClass = 'logic'
          if (this.filters[indexer] && index == 0)
          {
            this.filters[indexer].logic = val
          }
          else if (!this.filters[indexer] || index > 0)
          {
            this.filters.push({logic: val})
            indexer++
          }
        }
        else if (this.operatorKeywords.indexOf(val.trim()) > -1 && previousCssClass == 'logic') {
          optFriendString = this.oepratorToFriendlyString(val)
          newHTML +=
            "<span class='operator'>" +
            (optFriendString ? optFriendString : val)  +
            '</span>';
            previousCssClass = 'operator'
            if (this.filters[indexer])
          {
            this.filters[indexer].operator = val
          }
          else
          {
            this.filters.push({operator: val})
            indexer++
          }
        } 
        else if (previousCssClass == 'operator' && val != '')
        {
          let arrValSplitOnSingleQuote = val.split("'")
          let val2 =  val[0] == "'" && val[val.length -1] == "'" ? val.substring(1, val.length - 1) :  val
          let valWihtouSingleQuote = ''
          let valToShow = ''
          if (arrValSplitOnSingleQuote?.length > 0)
          {
            arrValSplitOnSingleQuote.forEach((x, idx, arx) => {
              let valWihtouSingleQuote2 = null
              if (x != "")
              {
                valWihtouSingleQuote2 = this.oepratorToFriendlyString(x)
              }
              if (!valWihtouSingleQuote2 && x != "")
              {
                valToShow += x
              }
              else if (valWihtouSingleQuote2 && x != "")
              {
                valToShow += valWihtouSingleQuote2
                valWihtouSingleQuote += valWihtouSingleQuote2
              }
              else if (x == "" && (idx < arx.length - 1 || (idx == arx.length - 1 && val.length > 2 && val[val.length - 1] == "'")))
              {
                valToShow += "'"
              }
              if (x =="" && arx.length > 4 && (idx == 1 || idx == arx.length -2) && arx[1] == "" && arx[arx.length-2] == "")
              {
                valWihtouSingleQuote += "'"
              }
            })
          }
          newHTML += "<span class='value'>" + valToShow  +'</span>';
          previousCssClass = 'value'
          if (this.filters[indexer])
          {
            this.filters[indexer].value = valWihtouSingleQuote ? valWihtouSingleQuote : val
            this.filters[indexer].fieldName = this.fieldName
          }
          else
          {
            this.filters.push({value: valWihtouSingleQuote ? valWihtouSingleQuote : val, fieldName: this.fieldName})
            indexer++
          }
        }
        else if (val != '')
        {
          newHTML += "<span class='value'>" + val  +'</span>';
          previousCssClass = 'value'
          if (this.filters[indexer]?.value)
          {
            this.filters[indexer].value += ' ' + val
          }
          else
          {
            this.filters.push({value: val[0] == "'" && val[val.length -1] == "'" ? val.substring(1, val.length - 1) :  val})
            indexer++
          }
        }
        if (index < array.length -1)
          newHTML += "<span class='other'>&nbsp;</span>"
      });

    //console.log(newHTML);
    // newHTML = newHTML.substring(0, newHTML.lastIndexOf('&nbsp;')) + '</span>'
    // console.log(newHTML);
    //console.log(this.filters)
    this.getFilters.emit(this.filters)

    return newHTML;
  }

}
